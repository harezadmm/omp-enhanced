---
name: sqlmap
description: SQL injection: automatic detection, exploitation, takeove...
category: red-team-arsenal/web-applications
tags: [pentesting, web applications, kali-linux, sqlmap]
author: auto-generated
created: 2026-09-04
---

# SQLMAP

**Category:** Web Applications  
**Description:** SQL injection: automatic detection, exploitation, takeover

## Installation

```bash
# Kali Linux
sudo apt-get update && sudo apt-get install -y sqlmap

# Check installation
which sqlmap
sqlmap --version || sqlmap -h
```

## Basic Usage

```bash
# Get help
sqlmap --help
sqlmap -h

# Common usage patterns will be updated after first use
```

## Key Features

- Part of Kali Linux web applications toolkit
- Industry-standard pentesting tool
- Active development and community support

## Common Workflows

*This section will be populated after tool usage and research*

## Pitfalls

- Always verify target authorization before scanning
- Some tools generate significant network traffic
- Check local laws regarding security testing
- Maintain operational security when running tools

## Resources

- Kali Tools: https://www.kali.org/tools/sqlmap/
- Official Documentation: Search for "sqlmap official documentation"
- Exploit-DB: https://www.exploit-db.com/

## Notes

- Auto-generated skill, will be enriched with usage patterns
- Last updated: 2026-09-04
