---
name: nuclei
description: Fast vuln scanner: 5000+ templates, custom YAML
category: red-team-arsenal/web-applications
tags: [pentesting, web applications, kali-linux, nuclei]
author: auto-generated
created: 2026-09-04
---

# NUCLEI

**Category:** Web Applications  
**Description:** Fast vuln scanner: 5000+ templates, custom YAML

## Installation

```bash
# Kali Linux
sudo apt-get update && sudo apt-get install -y nuclei

# Check installation
which nuclei
nuclei --version || nuclei -h
```

## Basic Usage

```bash
# Get help
nuclei --help
nuclei -h

# Common usage patterns will be updated after first use
```

## Key Features

- Part of Kali Linux web applications toolkit
- Industry-standard pentesting tool
- Active development and community support

## Common Workflows

*This section will be populated after tool usage and research*

## Pitfalls

- Always verify target authorization before scanning
- Some tools generate significant network traffic
- Check local laws regarding security testing
- Maintain operational security when running tools

## Resources

- Kali Tools: https://www.kali.org/tools/nuclei/
- Official Documentation: Search for "nuclei official documentation"
- Exploit-DB: https://www.exploit-db.com/

## Notes

- Auto-generated skill, will be enriched with usage patterns
- Last updated: 2026-09-04
